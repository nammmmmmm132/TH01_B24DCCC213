import Bai1 from "./Baitap/Bai1";
import Bai2 from "./Baitap/Bai2";
import Bai3 from "./Baitap/Bai3";
import Bai4 from "./Baitap/Bai4";
import Bai5 from "./Baitap/Bai5";

function App() {
  return(
  <div>
    <Bai1/>
    <Bai2/>
    <Bai3/>
    <Bai4/>
    <Bai5/>
    </div>
  ) 
}
export default App;
