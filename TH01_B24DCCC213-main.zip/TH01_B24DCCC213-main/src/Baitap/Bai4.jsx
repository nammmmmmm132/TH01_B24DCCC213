import { useState } from "react";

function LikeDislike({ text }) {
    const [ like , setLike ] = useState(0);
    const [ dislike, setDislike ] = useState(0)
 
   return (
    <div style={styles.postContainer}>
      <p>{text}</p>
      <div style={styles.buttonContainer}>
        <button onClick={() => setLike(like + 1)} style={styles.button}>👍 <span>{like}</span></button>
        <button onClick={() => setDislike(dislike + 1)} style={styles.button}>👎 <span>{dislike}</span></button>
      </div>
    </div>
    )
}

function Bai4(){
    return(
    <div style={{padding:'20px'}}>
    <h1>Bài 4: Like/Dislike Post</h1>
    <LikeDislike text="Học ReactJS có khó không?"/>
    <LikeDislike text="Props và State là gì?"/>
    <LikeDislike text="Lập trình web có vui không?"/>
    </div>
    )
}

const styles = {
  postContainer: {
    border: "1px solid #000",
    padding: "10px",
    marginBottom: "15px",
  },
};

export default Bai4