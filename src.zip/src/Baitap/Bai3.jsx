import React, { useState } from 'react';

function Bai3() {
  const products = [
    { name: 'Sách', price: 10000 },
    { name: 'Bút', price: 5000 },
    { name: 'Vở', price: 7000 }
  ];

  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  const addToCart = (product) => {
    setCart([...cart, product]); 
    setTotal(total + product.price); 
  };

  return (
    <div style={{padding:'20px'}}>
      <h1>Bài 3: Giỏ hàng</h1>
      <h3>Sản phẩm</h3>
      {products.map((product, index) => (
        <div key={index}>
          <span>{product.name} - {product.price}đ</span>
          <button onClick={() => addToCart(product)}>Thêm vào giỏ</button>
        </div>
      ))}

      <h3>Giỏ hàng</h3>
      <ul>
        {cart.map((item, index) => (
          <li key={index}>
            {item.name} - {item.price}đ
          </li>
        ))}
      </ul>

      <h3>Tổng tiền: {total}đ</h3>
    </div>
  );
}

export default Bai3;
