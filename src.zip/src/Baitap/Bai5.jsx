import React, { useState } from "react";

function Bai5() {
  const questions = [
    {
      question: "ReactJS dùng để làm gì?",
      options: ["Mobile App", "Web UI", "Hệ điều hành", "Cơ sở dữ liệu"],
      correctAnswer: "Web UI",
    },
    {
      question: "Props trong React là gì?",
      options: ["Trạng thái", "Thuộc tính truyền vào", "API", "CSS"],
      correctAnswer: "Thuộc tính truyền vào",
    },
    {
      question: "State dùng để làm gì?",
      options: ["Quản lý dữ liệu thay đổi", "Định nghĩa component", "Kết nối backend", "Trang trí giao diện"],
      correctAnswer: "Quản lý dữ liệu thay đổi",
    },
  ];

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index, option) => {
    setAnswers({
      ...answers,
      [index]: option,
    });

    if (index < questions.length - 1) {
      setCurrentQuestionIndex(index + 1);
    } else {

      setShowResult(true);
    }
  };

  const calculateScore = () => {
    let correctAnswers = 0;
    questions.forEach((q, index) => {
      if (answers[index] === q.correctAnswer) {
        correctAnswers++;
      }
    });
    return correctAnswers;
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div style={{ padding: "20px" }}>
      <h1>Bài 5: Quiz App</h1>

      {!showResult && (
        <div>
          <p>{currentQuestion.question}</p>
          {currentQuestion.options.map((option, i) => (
            <button
              key={i}
              onClick={() => handleAnswer(currentQuestionIndex, option)}
            >
              {option}
            </button>
          ))}
        </div>
      )}

      {showResult && (
        <div>
          <p>Số câu đúng: {calculateScore()} / {questions.length}</p>
        </div>
      )}
    </div>
  );
}

export default Bai5;
