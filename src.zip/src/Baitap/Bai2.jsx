import { useState } from 'react';

function ColorBox({ color }) {
  const boxStyle = {
    width: '100px',
    height: '100px',
    border: '1px solid black',
    backgroundColor: color,
  };

  return <div style={boxStyle}></div>;
}


function Bai2() {
  const [color, setColor] = useState('');

  return (
    <div style={{padding:'20px'}}>
      <h1>Bài 2: Color Picker</h1>
      <button onClick={() => setColor('red')}>Đỏ</button>
      <button onClick={() => setColor('blue')}>Xanh</button>
      <button onClick={() => setColor('yellow')}>Vàng</button>

      <ColorBox color={color} />
    </div>
  );
}

export default Bai2;
